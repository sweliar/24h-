#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
每日会议总结配置管理器
提供图形化界面配置API密钥、提示词、邮件设置等
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
from openai import OpenAI
from daily_summary_service import DailySummaryService

class ConfigManager:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("每日会议总结配置")
        self.root.geometry("600x700")
        
        self.service = DailySummaryService()
        self.config = self.service.config
        
        self.setup_ui()
        self.load_config_to_ui()
    
    def setup_ui(self):
        """设置用户界面"""
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # API配置
        api_frame = ttk.LabelFrame(main_frame, text="OpenAI API配置", padding="10")
        api_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(api_frame, text="API密钥:").grid(row=0, column=0, sticky=tk.W)
        self.api_key_entry = ttk.Entry(api_frame, width=50, show="*")
        self.api_key_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=5)
        
        ttk.Label(api_frame, text="API地址:").grid(row=1, column=0, sticky=tk.W)
        self.api_base_entry = ttk.Entry(api_frame, width=50)
        self.api_base_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), padx=5)
        
        ttk.Label(api_frame, text="模型:").grid(row=2, column=0, sticky=tk.W)
        self.model_entry = ttk.Entry(api_frame, width=50)
        self.model_entry.grid(row=2, column=1, sticky=(tk.W, tk.E), padx=5)
        
        # 提示词配置
        prompt_frame = ttk.LabelFrame(main_frame, text="提示词配置", padding="10")
        prompt_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(prompt_frame, text="提示词模板:").grid(row=0, column=0, sticky=tk.W)
        self.prompt_text = tk.Text(prompt_frame, height=8, width=60)
        self.prompt_text.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        
        # 定时任务配置
        schedule_frame = ttk.LabelFrame(main_frame, text="定时任务配置", padding="10")
        schedule_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(schedule_frame, text="执行时间 (HH:MM):").grid(row=0, column=0, sticky=tk.W)
        self.schedule_entry = ttk.Entry(schedule_frame, width=10)
        self.schedule_entry.grid(row=0, column=1, sticky=tk.W, padx=5)
        
        self.enabled_var = tk.BooleanVar()
        self.enabled_check = ttk.Checkbutton(schedule_frame, text="启用每日总结", variable=self.enabled_var)
        self.enabled_check.grid(row=0, column=2, sticky=tk.W, padx=20)
        
        # 邮件配置
        email_frame = ttk.LabelFrame(main_frame, text="邮件配置", padding="10")
        email_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(email_frame, text="SMTP服务器:").grid(row=0, column=0, sticky=tk.W)
        self.smtp_server_entry = ttk.Entry(email_frame, width=30)
        self.smtp_server_entry.grid(row=0, column=1, sticky=tk.W, padx=5)
        
        ttk.Label(email_frame, text="SMTP端口:").grid(row=0, column=2, sticky=tk.W, padx=5)
        self.smtp_port_entry = ttk.Entry(email_frame, width=10)
        self.smtp_port_entry.grid(row=0, column=3, sticky=tk.W)
        
        ttk.Label(email_frame, text="发件人邮箱:").grid(row=1, column=0, sticky=tk.W)
        self.sender_email_entry = ttk.Entry(email_frame, width=30)
        self.sender_email_entry.grid(row=1, column=1, sticky=tk.W, padx=5)
        
        ttk.Label(email_frame, text="发件人密码:").grid(row=1, column=2, sticky=tk.W, padx=5)
        self.sender_password_entry = ttk.Entry(email_frame, width=20, show="*")
        self.sender_password_entry.grid(row=1, column=3, sticky=tk.W)
        
        ttk.Label(email_frame, text="收件人邮箱 (用逗号分隔):").grid(row=2, column=0, sticky=tk.W)
        self.recipient_emails_entry = ttk.Entry(email_frame, width=50)
        self.recipient_emails_entry.grid(row=2, column=1, columnspan=3, sticky=(tk.W, tk.E), padx=5)
        
        # 按钮
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=4, column=0, pady=10)
        
        ttk.Button(button_frame, text="保存配置", command=self.save_config).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="测试总结", command=self.test_summary).grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="测试邮件", command=self.test_email).grid(row=0, column=2, padx=5)
        
        # 状态显示
        self.status_label = ttk.Label(main_frame, text="就绪")
        self.status_label.grid(row=5, column=0, pady=5)
    
    def load_config_to_ui(self):
        """加载配置到UI"""
        # API配置
        self.api_key_entry.insert(0, self.config.get('openai_api_key', ''))
        self.api_base_entry.insert(0, self.config.get('openai_api_base', 'https://ark.cn-beijing.volces.com/api/v3'))
        self.model_entry.insert(0, self.config.get('model', 'deepseek-v3-1-250821'))
        
        # 提示词
        self.prompt_text.insert('1.0', self.config.get('prompt_template', ''))
        
        # 定时任务
        self.schedule_entry.insert(0, self.config.get('schedule_time', '21:00'))
        self.enabled_var.set(self.config.get('enabled', True))
        
        # 邮件配置
        email_config = self.config.get('email_config', {})
        self.smtp_server_entry.insert(0, email_config.get('smtp_server', 'smtp.gmail.com'))
        self.smtp_port_entry.insert(0, str(email_config.get('smtp_port', 587)))
        self.sender_email_entry.insert(0, email_config.get('sender_email', ''))
        self.sender_password_entry.insert(0, email_config.get('sender_password', ''))
        
        recipients = email_config.get('recipient_emails', [])
        self.recipient_emails_entry.insert(0, ', '.join(recipients))
    
    def save_config(self):
        """保存配置"""
        try:
            # 更新配置
            self.config['openai_api_key'] = self.api_key_entry.get()
            self.config['openai_api_base'] = self.api_base_entry.get()
            self.config['model'] = self.model_entry.get()
            self.config['prompt_template'] = self.prompt_text.get('1.0', tk.END).strip()
            self.config['schedule_time'] = self.schedule_entry.get()
            self.config['enabled'] = self.enabled_var.get()
            
            # 邮件配置
            self.config['email_config'] = {
                'smtp_server': self.smtp_server_entry.get(),
                'smtp_port': int(self.smtp_port_entry.get()),
                'sender_email': self.sender_email_entry.get(),
                'sender_password': self.sender_password_entry.get(),
                'recipient_emails': [email.strip() for email in self.recipient_emails_entry.get().split(',') if email.strip()]
            }
            
            # 保存到文件
            if self.service.save_config():
                messagebox.showinfo("成功", "配置已保存")
                self.status_label.config(text="配置已保存")
            else:
                messagebox.showerror("错误", "保存配置失败")
                
        except Exception as e:
            messagebox.showerror("错误", f"保存配置时出错: {e}")
    
    def test_summary(self):
        """测试总结功能"""
        self.status_label.config(text="正在测试总结功能...")
        self.root.update()
        
        try:
            service = DailySummaryService()
            service.test_summary()
            messagebox.showinfo("成功", "测试完成，请查看控制台输出")
            self.status_label.config(text="测试完成")
        except Exception as e:
            messagebox.showerror("错误", f"测试失败: {e}")
            self.status_label.config(text="测试失败")
    
    def test_email(self):
        """测试邮件发送"""
        self.status_label.config(text="正在测试邮件发送...")
        self.root.update()
        
        try:
            service = DailySummaryService()
            service.send_email("这是测试邮件，用于验证邮件配置是否正确。")
            messagebox.showinfo("成功", "测试邮件已发送")
            self.status_label.config(text="邮件测试完成")
        except Exception as e:
            messagebox.showerror("错误", f"邮件测试失败: {e}")
            self.status_label.config(text="邮件测试失败")
    
    def run(self):
        """运行配置管理器"""
        self.root.mainloop()

if __name__ == "__main__":
    app = ConfigManager()
    app.run()