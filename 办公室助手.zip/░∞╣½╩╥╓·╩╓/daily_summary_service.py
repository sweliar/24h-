#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
每日会议总结服务
自动收集当天会议文本，调用大模型生成总结，并发送邮件
"""
import os
from openai import OpenAI
import os
import json
import smtplib
import schedule
import time
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import glob

class DailySummaryService:
    def __init__(self, config_path="daily_summary_config.json"):
        self.config_path = config_path
        self.config = self.load_config()
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        
    def load_config(self):
        """加载配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"加载配置文件失败: {e}")
            return {}
    
    def save_config(self):
        """保存配置文件"""
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存配置文件失败: {e}")
            return False
    
    def get_today_meeting_texts(self):
        """获取当天的所有会议文本"""
        today = datetime.now().strftime('%Y-%m-%d')
        meeting_text_dir = os.path.join(self.base_dir, "会议文本", today)
        
        if not os.path.exists(meeting_text_dir):
            print(f"未找到当天的会议文本目录: {meeting_text_dir}")
            return []
        
        meeting_texts = []
        txt_files = glob.glob(os.path.join(meeting_text_dir, "*.txt"))
        
        for txt_file in txt_files:
            try:
                with open(txt_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    filename = os.path.basename(txt_file)
                    meeting_texts.append({
                        'filename': filename,
                        'content': content,
                        'time': datetime.fromtimestamp(os.path.getmtime(txt_file)).strftime('%H:%M')
                    })
            except Exception as e:
                print(f"读取会议文件失败 {txt_file}: {e}")
        
        return meeting_texts
    
    def generate_summary_with_openai(self, meeting_texts):
        """使用OpenAI API生成会议总结"""
        if not meeting_texts:
            return "今天没有会议记录"
        
        # 合并所有会议文本
        combined_text = ""
        for meeting in meeting_texts:
            combined_text += f"\n【会议文件: {meeting['filename']} - {meeting['time']}】\n"
            combined_text += meeting['content'] + "\n"
        
        # 使用自定义提示词
        prompt = self.config.get('prompt_template', '').format(meeting_text=combined_text)
        
        headers = {
            'Authorization': f"Bearer {self.config.get('openai_api_key', '')}",
            'Content-Type': 'application/json'
        }
        
        data = {
            'model': self.config.get('model', 'deepseek-v3-1-250821'),
            'messages': [
                {'role': 'system', 'content': '你是一个专业的会议总结助手，请根据提供的会议记录生成清晰、准确的会议纪要。'},
                {'role': 'user', 'content': prompt}
            ],
            'max_tokens': 2000,
            'temperature': 0.7
        }
        
        try:
            response = requests.post(
                f"{self.config.get('openai_api_base', 'https://ark.cn-beijing.volces.com/api/v3')}/chat/completions",
                headers=headers,
                json=data,
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                return result['choices'][0]['message']['content']
            else:
                print(f"API调用失败: {response.status_code} - {response.text}")
                return f"API调用失败: {response.status_code}"
                
        except Exception as e:
            print(f"调用OpenAI API失败: {e}")
            return f"调用API失败: {str(e)}"
    
    def save_summary_to_file(self, summary):
        """保存总结到本地文件"""
        today = datetime.now().strftime('%Y-%m-%d')
        summary_dir = os.path.join(self.base_dir, "每日会议总结")
        
        if not os.path.exists(summary_dir):
            os.makedirs(summary_dir)
            print(f"创建每日会议总结目录: {summary_dir}")
        
        filename = f"每日会议总结_{today}.txt"
        filepath = os.path.join(summary_dir, filename)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(f"每日会议总结 - {today}\n")
                f.write("=" * 50 + "\n\n")
                f.write(summary)
            
            print(f"会议总结已保存: {filepath}")
            return filepath
            
        except Exception as e:
            print(f"保存总结文件失败: {e}")
            return None
    
    def send_email(self, summary):
        """发送邮件"""
        email_config = self.config.get('email_config', {})
        
        if not email_config.get('sender_email') or not email_config.get('recipient_emails'):
            print("邮件配置不完整，跳过发送")
            return False
        
        try:
            msg = MIMEMultipart()
            msg['From'] = email_config['sender_email']
            msg['To'] = ', '.join(email_config['recipient_emails'])
            msg['Subject'] = f"每日会议总结 - {datetime.now().strftime('%Y-%m-%d')}"
            
            body = f"""
亲爱的用户，

这是您今天的会议总结报告：

{summary}

---
由会议助手自动生成
时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            """
            
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            server = smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port'])
            server.starttls()
            server.login(email_config['sender_email'], email_config['sender_password'])
            
            text = msg.as_string()
            server.sendmail(email_config['sender_email'], email_config['recipient_emails'], text)
            server.quit()
            
            print(f"邮件已发送到: {', '.join(email_config['recipient_emails'])}")
            return True
            
        except Exception as e:
            print(f"发送邮件失败: {e}")
            return False
    
    def run_daily_summary(self):
        """执行每日会议总结"""
        if not self.config.get('enabled', True):
            print("每日会议总结功能已禁用")
            return
        
        print("开始执行每日会议总结...")
        
        # 获取当天的会议文本
        meeting_texts = self.get_today_meeting_texts()
        
        if not meeting_texts:
            print("今天没有会议记录")
            summary = "今天没有会议记录"
        else:
            print(f"发现 {len(meeting_texts)} 个会议记录，正在生成AI总结...")
            # 生成总结
            summary = self.generate_summary_with_openai(meeting_texts)
            
            # 检查AI是否成功生成总结
            if "API调用失败" in summary or "调用API失败" in summary:
                print("AI总结生成失败，将使用基础总结格式")
                summary = self.generate_basic_summary(meeting_texts)
        
        # 保存到本地
        saved_path = self.save_summary_to_file(summary)
        
        # 等待AI处理完成后发送邮件
        if saved_path and self.config.get('email_config', {}).get('sender_email'):
            print("等待2秒后发送邮件...")
            time.sleep(2)  # 确保文件保存完成
            email_sent = self.send_email(summary)
            if email_sent:
                print("邮件发送成功")
            else:
                print("邮件发送失败，但总结已保存到本地")
        else:
            print("邮件配置不完整或总结保存失败，跳过邮件发送")
        
        print("每日会议总结任务完成")
    
    def generate_basic_summary(self, meeting_texts):
        """生成基础总结（当AI调用失败时使用）"""
        summary_parts = []
        summary_parts.append(f"今日共进行了 {len(meeting_texts)} 场会议")
        summary_parts.append("\n会议列表：")
        
        for i, meeting in enumerate(meeting_texts, 1):
            content_preview = meeting['content'][:200] + "..." if len(meeting['content']) > 200 else meeting['content']
            summary_parts.append(f"{i}. {meeting['filename']} ({meeting['time']})")
            summary_parts.append(f"   内容预览：{content_preview}")
            summary_parts.append("")
        
        return "\n".join(summary_parts)
    
    def schedule_daily_task(self):
        """设置定时任务"""
        schedule_time = self.config.get('schedule_time', '21:00')
        schedule.every().day.at(schedule_time).do(self.run_daily_summary)
        
        print(f"已设置每日会议总结任务，执行时间: {schedule_time}")
        
        while True:
            schedule.run_pending()
            time.sleep(60)
    
    def test_summary(self):
        """测试总结功能"""
        print("测试每日会议总结功能...")
        self.run_daily_summary()

if __name__ == "__main__":
    import sys
    
    service = DailySummaryService()
    
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        service.test_summary()
    else:
        service.schedule_daily_task()