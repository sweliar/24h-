# 每日会议总结系统快速启动指南

## 🚀 立即开始使用

### 第一步：配置API密钥
1. 双击运行 `配置每日总结.bat`
2. 在弹出的窗口中输入：
   - **OpenAI API密钥**: 从 https://platform.openai.com/account/api-keys 获取
   - **邮件设置**: 配置SMTP服务器和邮箱信息（可选）
3. 点击"保存配置"

### 第二步：测试功能
1. 在配置管理器中点击"测试总结"按钮
2. 检查 `每日会议总结/` 文件夹中是否生成了总结文件

### 第三步：启动定时服务
1. 双击运行 `start_daily_summary.bat`
2. 服务将在后台运行，每天21:00自动执行总结任务

## 📁 文件说明

### 核心文件
- `daily_summary_service.py`: 核心服务程序
- `config_manager.py`: 图形化配置工具
- `daily_summary_config.json`: 配置文件（自动创建）

### 目录结构
```
办公室助手/
├── 会议文本/                    # 会议记录输入
│   └── 2025-09-04/           # 按日期分类
├── 每日会议总结/               # 生成的总结文件
└── 其他系统文件...
```

## ⚙️ 配置示例

### OpenAI配置
```json
{
  "openai_api_key": "sk-your-key-here",
  "model": "gpt-3.5-turbo",
  "schedule_time": "21:00"
}
```

### 邮件配置示例（Gmail）
```json
{
  "email_config": {
    "smtp_server": "smtp.gmail.com",
    "smtp_port": 587,
    "sender_email": "your@gmail.com",
    "sender_password": "your-app-password",
    "recipient_emails": ["recipient1@example.com", "recipient2@example.com"]
  }
}
```

## 🔧 故障解决

### 常见问题
1. **缺少依赖**: 运行 `pip install schedule requests`
2. **API失败**: 检查API密钥和网络连接
3. **邮件失败**: 验证SMTP配置和邮箱密码

### 手动测试
```bash
python daily_summary_service.py test
```

## 📊 功能特点
- ✅ 自动收集当天会议文本
- ✅ 智能AI生成会议纪要
- ✅ 本地文件保存
- ✅ 邮件自动发送
- ✅ 自定义提示词
- ✅ 定时任务执行
- ✅ 图形化配置界面

## 📞 技术支持
如有问题，请检查控制台输出或查看生成的日志文件。

**现在就开始使用吧！** 双击 `配置每日总结.bat` 开始配置您的每日会议总结系统。